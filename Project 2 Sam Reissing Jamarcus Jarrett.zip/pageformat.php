<?php

function pageheader($img, $title, $logged)
{
	echo "<div class= \"row\">";
	echo "<div class= \"col-sm-2\">";
	echo "<img src=\"$img\" class=\"rounded float-start\" alt=\"$img\" width=\"100\" height=\"100\">";
	echo "</div>";

	echo "<div class= \"topnav\" style = \"background-image: url(\"./imagesBackground.jpg\");\">";
	  echo "<a href=\"index.php\">Home </a>";
	  echo "<a href=\"rides.php\">Rides </a>";
	  echo "<a href=\"rewards.php\">Rewards </a>";
	  echo "<a href=\"signup.php\">Sign Up </a>";
	  echo "<input type=\"text\" placeholder=\"Search..\">";
	  if($logged)
	  {
	  	echo "<a href=\"userloginform.php\">Log In</a>";
	  }
	  else
	  {
	  	echo "<a href=\"logout.php\">Log Out</a>";
	  	echo "<a href=\"cart.html\"><img src = \"./image/cart.png\" alt = \"cart\" width = \"20\" hight = \"20\"></a>";
	  }  	
	echo "</div>";
	echo "</div>";
}

function pagefooter()
{
	echo "<div class= \"row\">";
	echo "<p><i>Milledgeville Taxi Service</i> 2022 &copy;</p>";
	echo "<a href=\"loginform.php\">Admin Login</a>";
	echo "</div>";
}


?>