<?php
session_start();
if(!isset($_SESSION['name']))
{
  $logged = true;
}
else{
  $logged = false;
}
$_UNAME = $_SESSION['name'];
?>
<!doctype html>

<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Certified Transportation LLC</title>
  <link rel = "stylesheet" href = "style.css">

  <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>

<body>
  <div id="page-container">
    <div id="content-wrap">
      <?php
        require_once 'pageformat.php';
        require_once "connection.php";
        pageheader("images/logo.jpg", "Home", $logged);
      ?>
        <div class="bg-image" style="z-index: -1">
          <h1 style= "background-color: white;">My Account</h1>
          <?php
            $conn=connectDB();
            if(!$conn)
            {
              echo "connecting failed, try again later!";
              die("Failed on DB Connection");
            }
            $conn->close();
          ?>
        </div>
         <div class = "row" style="padding-left: 50px;">
        <div class = "col-6">
          <?php
          	$conn=connectDB();
          	if(!$conn)
            {
              echo "connecting failed, try again later!";
              die("Failed on DB Connection");
            }

            $uName = $_SESSION['name'];

            $getAccount = "SELECT * FROM taxiUser WHERE userName = '$uName'";
            $accountResult = mysqli_query($conn, $getAccount);

            while($row = $accountResult->fetch_assoc())
              {
              	echo "<p2 sytle = \"font-weight:bold;\">First Name: ".$row["firstName"]."</p>";
              	echo "<p2 sytle = \"font-weight:bold;\">Last Name: ".$row["lastName"]."</p>";
              	echo "<p2 sytle = \"font-weight:bold;\">User Name: ".$row["userName"]."</p>";
              	echo "<p2 sytle = \"font-weight:bold;\">Email: ".$row["email"]."</p>";
              	echo "<p hidden>".$row["pwd"]."</p>";
              	echo "<p hidden>".$row["userId"]."</p>";
              }

            $conn->close();
          ?>
          
          <br>
          <br>
          <br>
          <br>
          <br>
          <h2>
            Ride History
          </h2>
          <?php
            $conn=connectDB();
            if(!$conn)
            {
              echo "connecting failed, try again later!";
              die("Failed on DB Connection");
            }

            $sql = "SELECT * FROM rides WHERE userName = '$uName'";
            $result = mysqli_query($conn, $sql);

            if(isset($_POST['deleteButton']))
              {
                $delete = 'DELETE from rides WHERE ID = ?';
                $stmt = $conn->prepare($delete);
                $stmt->bind_param("i", $_POST['deleteButton']);
                $stmt->execute();
                echo "The ride has been sucessfully deleted";
                header("Refresh:2");
              }

            if(isset($_POST['editButton']))
              {
                $uName = $_SESSION['name'];
                $strID = strval($_POST['editButton']);
                $str = "SELECT * FROM rides WHERE ID =".$strID;
                $thisResult = mysqli_query($conn, $str);

                while($item = $thisResult->fetch_assoc())
                {
                  $id = $item["ID"];
                  $date = $item["date"];
                  $pickup = $item["pickup"];
                  $destination = $item["destination"];
                  $driver = $item["driver"];
                  $distance = $item["distance"];
                  $cost = $item["cost"];
                }

                echo "<table class=\"table\">
                    <tr>
                      <th>ID</th>
                      <th>Date</th>
                      <th>Pickup Location</th>
                      <th>Destination</th>
                      <th>Driver</th>
                      <th>Distance</th>
                      <th>Cost</th>
                      <th>Submit Changes</th>
                      <th>Cancel</th>
                    </tr>";
                echo "<form method = \"POST\">
                        <tr>
                          <td><input type = \"hidden\" name = \"id\" value = \"$id\">$id</td>
                          <td><input type = \"text\" name = \"date\" value = \"$date\"></td>
                          <td><input type = \"text\" name = \"pickup\" value = \"$pickup\"></td>
                          <td><input type = \"text\" name = \"destination\" value = \"$destination\"></td>
                          <td><input type = \"text\" name = \"driver\" value = \"$driver\"></td>
                          <td><input type = \"number\" name = \"distance\" value = \"$distance\"></td>
                          <td>$cost</td>
                          <td><input type = \"submit\" name = \"editSubmit\" value = \"Submit\"></td>
                          <td><input type = \"submit\" name = \"editCancel\" value = \"Cancel\"></td>
                        </tr>
                      </form>";                  
              }

            if(isset($_POST['editSubmit']))
              {
                $id = $_POST["id"];
                $date = $_POST["date"];
                $pickup = $_POST["pickup"];
                $destination = $_POST["destination"];
                $driver = $_POST["driver"];
                $distance = $_POST["distance"];

                $edit = "UPDATE rides SET date = '$date',
                                  pickup = '$pickup',
                                  destination = '$destination',
                                  driver = '$driver',
                                  distance = '$distance'
                              WHERE ID = ".$id;
                $conn->query($edit);
                echo "The ride has been sucessfully changed!";
                header("Refresh:2");
              }

            if ($result->num_rows > 0)
            {
              echo "<table class=\"table\">
                      <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Pickup Location</th>
                        <th>Destination</th>
                        <th>Driver</th>
                        <th>Distance</th>
                        <th>Cost</th>
                        <th>Edit Field</th>
                        <th>Delete Ride</th>
                      </tr>";
              while($row = $result->fetch_assoc())
              {
                echo "<tr>
                        <td>".$row["ID"]."</td>
                        <td>".$row["date"]."</td>
                        <td>".$row["pickup"]."</td>
                        <td>".$row["destination"]."</td>
                        <td>".$row["driver"]."</td>
                        <td>".$row["distance"]."</td>
                        <td>".$row["cost"]."</td>
                        <td>
                          <form method = \"POST\">
                            <button type = \"submit\" value=".$row['ID']." name = \"editButton\" class=\"btn btn-success\">EDIT</button>
                          </form>
                        </td>
                        <td>
                          <form method = \"POST\">
                            <button type = \"submit\" value=".$row['ID']." name = \"deleteButton\" class=\"btn btn-danger\">DELETE</button>
                          </form>
                        </td>
                      </tr>";
              }
              echo "</table>";
            }
            else
            {
              echo "<br> You have no rides on record";
            }
          ?>

        </div>
        <!--
        </div>
          <form id = "rewardForm" action="/action_page.php">
            <br>
            <br>
            <label for="rewards">Enter the cost of last trip:</label><br>
            <input type="number" id="rewards" name="rewards"><br>
          </form> 
          <button class="btn btn-primary" onclick="generateRewards()">Claim Rewards</button>
          <p id = "showRewards"></p>
        </div>
    	-->
        <footer>
            <?php  
              require_once 'pageformat.php';
              pagefooter();
            ?>
        </footer>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
  -->
  </div>
</body>
</html>