<?php
session_start();
if(!isset($_SESSION['name']))
{
  $logged = true;
}
else{
  $logged = false;
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
  <title>Home</title>
  <link rel = "stylesheet" href = "style.css">

  <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  </head>
  <body>
    <div class = "container";>
    <?php
    require_once 'pageformat.php';
    require_once "connection.php";
    pageheader("images/logo.jpg", "Home", $logged);

    $conn = connectDB();

    $email = $_POST["email"];
    $pwd = $_POST["pwd"];
    //$passwordHash = $_POST["pwd"];
    $passwordHash = sha1($_POST['pwd']);
    $query = "SELECT * FROM taxiUser WHERE pwd=\"$passwordHash\" AND email=\"$email\"";
    $result = $conn->query($query);
    if(!$result) 
      die("Query error on login!");

    if ($result->num_rows > 0)
      {
      while($row = $result->fetch_assoc())
      {
        //$row = $result->fetch_array(MYSQLI_ASSOC);
        $username = $row["firstName"];
        echo "<h2>Welcome Back! ".$row["firstName"]."</h2>";
        $_SESSION['name'] = $row["userName"];
        //print_r($row["userName"]);
        //print_r($_SESSION['name']);
        header('location:index.php');
        }
      }
      else
        {
          echo "<h2>Login Failed!</h2>";
        } 
      $conn->close();
    ?>
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </div>
  </body>
</html>