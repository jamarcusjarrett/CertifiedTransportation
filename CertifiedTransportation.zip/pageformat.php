<?php

function pageheader($img, $title, $logged)
{
	echo "<div class= \"row\">";
	echo "<div class= \"col-sm-2\">";
	echo "<img src=\"$img\" class=\"rounded float-start\" alt=\"$img\" width=\"400\" height=\"200\">";
	echo "</div>";

	echo "<div class= \"topnav\" style = \"background-image: url(\"./logo.jpg\") repeat #cfcfe6;\">";
	  echo "<a href=\"index.php\">Home </a>";
	  echo "<a href=\"rides.php\">Rides </a>";
	  echo "<a href=\"account.php\">Account </a>";
	  //echo "<input type=\"text\" placeholder=\"Search..\">";
	  if($logged)
	  {
	  	echo "<a href=\"signup.php\">Log In</a>";
	  }
	  else
	  {
	  	echo "<a href=\"logout.php\">Log Out </a>";
	  }  	
	echo "</div>";
	echo "</div>";
}

function pagefooter()
{
	echo "<div class= \"row\">";
	echo "<p><i>Serving Milledgeville, Georgia and Surrounding Counties</i> 2022 &copy;</p>";
	echo "<a href=\"userloginform.php\">Admin Login</a>";
	echo "</div>";
}


?>