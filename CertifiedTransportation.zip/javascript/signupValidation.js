"use strict"
function validateemail(id)
{
	let field=id.value;
	let good=false;
	let msg=document.getElementById("emailmsg");
	if(field === "")
	{
		msg.innerHTML="Email can not be empty!";
		msg.className="text-danger";
	}
	else
		if(!(/^(.+)@(.+)$/.test(field)))
		{
			msg.innerHTML="Email is not correct!";
			msg.className="text-danger";
		}
}
function validatepassword(id)
{
	let field = id.value;
	var good = false;
	var msg=document.getElementById("pwdmsg");
	if(field === "")
	{
		document.getElementById("pwdmsg").innerHTML="Password can not be empty";
		document.getElementById("pwdmsg").className="text-danger";
	}
	else if(!(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/.test(field)))
		{
			document.getElementById("pwdmsg").innerHTML="Password does not meet minimum requirements!";
			document.getElementById("pwdmsg").className="text-danger";
			document.getElementById("pwdmsg").className="Password must be at least 6 characters, and cannot be entirely alphabetic or numeric!";
		}
	else
	{
		good=true;
		localStorage.clear();
	}
	return good;
}
function validate(id)
{
	let emailId=document.getElementById("email");
	let phoneId=document.getElementById("password");
	if(validateemail(emailId)&&validatepassword(pwdId))
	{
		return true;
	}
	else
		return false;
}
function validateMiles(id)
{
	let field =id.value;
	let good=false;
	let msg=document.getElementById("intmsg");
	if(field ==="")
	{
		msg.innerHTML="Mileage can not be empty to continue";
		msg.className="text-danger";
	}
	else
		if(!/^[0-9]+$/.test(field))
		{
			document.getElementById("intmsg").innerHTML="Mileage should only be numeric!";
			document.getElementById("intmsg").innerHTML="text-danger";
		}
}