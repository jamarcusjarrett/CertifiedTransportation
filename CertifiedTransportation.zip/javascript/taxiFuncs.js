function calculateRide()
{
	var tripMiles = document.getElementById("tripCost");
	var baseFee = 3.75;
	var costPerMile = 2.00;
	
	let tripCost = baseFee + (costPerMile * tripMiles.elements[0].value);

	var text = "" + tripCost;
	document.getElementById("cost").innerHTML = text;
}

function generateRewards()
{
	var previousTrip = document.getElementById("rewardForm");
	let rewards = previousTrip.elements[0].value * 3;

	var rText = "" + rewards;
	document.getElementById("showRewards").innerHTML = rText;
}

function accruedRewards(rewards)
{
	let totalRewards = 0;
}

function applyRewards()
{
	tripCost - accruedRewards();
}