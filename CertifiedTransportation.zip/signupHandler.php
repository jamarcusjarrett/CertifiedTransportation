<?php
session_start();
if(!isset($_SESSION['name']))
{
  $logged = true;
}
else
{
  $logged = false;
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <title>Home</title>
  <link rel = "stylesheet" href = "style.css">

  <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    <title>Sign Up</title>
  </head>
  <body>
    <div id="page-container">
    <div id="content-wrap">
<?php
    require_once 'pageformat.php';
    require_once 'connection.php';
    pageheader("images/logo.jpg", "Home", $logged);
    $conn = connectDB();
     //Each value to be inserted
     $firstName = $_POST["firstName"];
     $email = $_POST["email"];
     $pwd = $_POST["password"];
     $userName = $_POST["userName"];
     $lastName = $_POST["lastName"];
     //SHA1 encrypts the entered password
     $passwordHash = sha1($_POST['password']);
     $sql = "INSERT INTO taxiUser(firstName, lastName, userName, pwd, email) VALUES (\"$firstName\",\"$lastName\",\"$userName\",\"$passwordHash\",\"$email\")";
     $deleter = "DELETE FROM taxiUser WHERE userName = ''";
     //Cancels the request if the database refuses to connect
     if ($conn->connect_error) 
     {
         die("Connection failed: " . $conn->connect_error);
     }
     //Messages romoted when connection is successful or not
     if ($conn->query($sql) == TRUE) 
     {
        echo "You have successfully signed up! ";
         echo "<a href=\"userloginForm.php\">Login Now?</a>"; 
         $conn->query($deleter);      
     } 
     else 
     {
        echo "Error: " . $sql . "<br>" . $conn->error;
     }
     //closes the database connection
     $conn->close();

?>

<?php
//shows the page footer
 pageFooter();
 ?>
</div>
</div>
</body>