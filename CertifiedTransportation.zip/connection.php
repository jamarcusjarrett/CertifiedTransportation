<?php
function connectDB()
{
	//for local db server
	$hn = "localhost";
	$un = "phpUser1";
	$pwd = "Phpadmin@1234";
	$db = "taxidb";

	//for production db server
	//$hn = "localhost";
	//$un = "u748872172_certifiedtsp";
	//$pwd = "Tigers_2018";
	//$db = "u748872172_taxiDB";

	$conn = new mysqli($hn,$un,$pwd,$db);
	if ($conn->connect_error) 
		die("Fatal error on connecting DB");

	return $conn;
} 
?>