-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2022 at 02:51 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taxidb`
--

-- --------------------------------------------------------

--
-- Table structure for table `rides`
--

CREATE TABLE `rides` (
  `ID` int(11) NOT NULL,
  `date` date NOT NULL,
  `pickup` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `driver` varchar(30) NOT NULL,
  `distance` double NOT NULL,
  `cost` double NOT NULL,
  `userName` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rides`
--

INSERT INTO `rides` (`ID`, `date`, `pickup`, `destination`, `driver`, `distance`, `cost`, `userName`) VALUES
(1, '2022-05-03', 'The Brick', 'Revelry Flats', 'Jamarcus', 2, 7.75, 'SamReissing'),
(2, '2022-05-04', 'The Brick', 'destination', 'Jamarcus', 3, 9, 'SamReissing'),
(4, '2022-05-04', 'The Brick', 'destination', 'Jamarcus', 3, 5, ''),
(5, '2022-05-04', 'The Brick', 'destination', 'Jamarcus', 3, 3, ''),
(9, '2022-05-04', 'The Brick', 'destination', 'Jamarcus', -5, 5, 'Susan');

-- --------------------------------------------------------

--
-- Table structure for table `taxiuser`
--

CREATE TABLE `taxiuser` (
  `userId` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pwd` varchar(40) NOT NULL,
  `uId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxiuser`
--

INSERT INTO `taxiuser` (`userId`, `firstName`, `lastName`, `userName`, `email`, `pwd`, `uId`) VALUES
(0, 'Samuel', 'Reissing', 'SamReissing', 'Samtot172@gmail.com', '6221513459577104765e518901b539df20dc426c', NULL),
(0, 'Susan', 'Reissing', 'Susan', 'susan@gmail.com', '6221513459577104765e518901b539df20dc426c', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `taxiusers`
--

CREATE TABLE `taxiusers` (
  `userId` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pwd` varchar(40) NOT NULL,
  `username` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxiusers`
--

INSERT INTO `taxiusers` (`userId`, `firstName`, `lastName`, `email`, `pwd`, `username`) VALUES
(0, 'Samuel', '', 'sam@gmail.com', '6221513459577104765e518901b539df20dc426c', NULL),
(0, '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', NULL),
(0, 'Samuel', '', 'samtot172@gmail.com', 'c91be01a87207aace34e2f127aa8996183a618b6', NULL),
(0, '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', NULL),
(1, 'Samuel', '', 'samtot172@gmail.com', '6221513459577104765e518901b539df20dc426c', NULL),
(1, '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', NULL),
(1, 'Samuel', '', 'samtot172@gmail.com', '6221513459577104765e518901b539df20dc426c', NULL),
(1, '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', NULL),
(2, 'sam', 'reissing', 'samuel@sam.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'samr'),
(1, 'Samuel', '', 'samtot172@gmail.com', '6221513459577104765e518901b539df20dc426c', NULL),
(1, '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', NULL),
(0, 'Samuel', '', 'samtot172@gmail.com', '6221513459577104765e518901b539df20dc426c', NULL),
(0, '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', NULL),
(0, 'Samuel', '', 'samtot172@gmail.com', 'b44dda1dadd351948fcace1856ed97366e679239', NULL),
(0, '', '', '', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `name` char(100) NOT NULL,
  `password` char(200) NOT NULL,
  `email` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `name`, `password`, `email`) VALUES
(1, 'Jamarcus Jarrett', 'JJ1', 'jamarcusjarrett@yahoo.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rides`
--
ALTER TABLE `rides`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
